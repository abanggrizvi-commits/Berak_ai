import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const model = process.env.OPENAI_MODEL || "gpt-6-luna";

app.use(cors());
app.use(express.json({ limit: "1mb" }));

app.get("/health", (_req, res) => {
  res.json({ ok: true, app: "BREAK AI" });
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Message is required" });

    const history = Array.isArray(req.body?.history)
      ? req.body.history.slice(-20)
      : [];

    const input = [
      ...history.map(x => ({
        role: x.r === "u" ? "user" : "assistant",
        content: String(x.t || "")
      })),
      { role: "user", content: message }
    ];

    const response = await client.responses.create({ model, input });
    res.json({ reply: response.output_text || "No response received." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI request failed" });
  }
});

app.listen(port, () => {
  console.log(`BREAK AI server running on port ${port}`);
});
